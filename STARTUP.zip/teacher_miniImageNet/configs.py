# TODO: Set the directory to save the model
save_dir = './logs_deterministic'

# TODO: Set the directory to the miniImageNet/tieredImageNet dataset
miniImageNet_path = '/scratch/datasets/miniImageNet_full_resolution/train'
tiered_ImageNet_path = '/scratch/datasets/tiered_imagenet/tiered_imagenet/original_split/train'
