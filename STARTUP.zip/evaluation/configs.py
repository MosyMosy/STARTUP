
# TODO: Please set the directory to the target datasets accordingly
ISIC_path = "/scratch/datasets/CD-FSL/ISIC"
ChestX_path = "/scratch/datasets/CD-FSL/chestX"
CropDisease_path = "/scratch/datasets/CD-FSL/CropDiseases"
EuroSAT_path = "/scratch/datasets/CD-FSL/EuroSAT/2750"
miniImageNet_path = '/scratch/datasets/CD-FSL/miniImageNet_test'
tiered_ImageNet_path = '/scratch/datasets/tiered_imagenet/tiered_imagenet/original_split/test'
